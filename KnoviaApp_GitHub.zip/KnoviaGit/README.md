# Knovia Android App

## كيفية بناء APK

### المتطلبات:
- Android Studio (Hedgehog أو أحدث)
- JDK 11 أو أحدث

### خطوات البناء:

1. **افتح المشروع في Android Studio:**
   - File → Open → اختر مجلد KnoviaApp

2. **انتظر Gradle Sync:**
   - سيقوم Android Studio بتحميل المكتبات تلقائياً

3. **بناء APK للنشر:**
   - Build → Generate Signed Bundle / APK
   - اختر APK
   - أنشئ keystore جديد أو استخدم موجود
   - اختر release
   - انتهى! ستجد APK في: app/release/app-release.apk

4. **بناء APK للاختبار (بدون توقيع):**
   - Build → Build Bundle(s) / APK(s) → Build APK(s)
   - ستجد APK في: app/build/outputs/apk/debug/

## معلومات التطبيق:
- **الاسم:** Knovia
- **Package:** com.knovia.app
- **Min Android:** 5.0 (API 21)
- **Target Android:** 14 (API 34)
